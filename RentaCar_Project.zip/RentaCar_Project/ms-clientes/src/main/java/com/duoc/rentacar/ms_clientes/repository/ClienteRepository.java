package com.duoc.rentacar.ms_clientes.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.duoc.rentacar.ms_clientes.model.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
}