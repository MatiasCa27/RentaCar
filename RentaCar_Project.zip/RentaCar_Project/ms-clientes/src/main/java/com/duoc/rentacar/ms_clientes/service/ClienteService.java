package com.duoc.rentacar.ms_clientes.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.duoc.rentacar.ms_clientes.model.Cliente;
import com.duoc.rentacar.ms_clientes.repository.ClienteRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class ClienteService {
    private static final Logger logger = LoggerFactory.getLogger(ClienteService.class);

    @Autowired
    private ClienteRepository repository;

    public List<Cliente> listarTodos() {
        logger.info("Buscando todos los clientes en la base de datos");
        return repository.findAll();
    }
}