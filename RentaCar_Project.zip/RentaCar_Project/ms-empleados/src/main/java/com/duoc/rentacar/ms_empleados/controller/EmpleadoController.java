package com.duoc.rentacar.ms_empleados.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus; // IMPORTANTE
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid; // IMPORTANTE

import com.duoc.rentacar.ms_empleados.model.Empleado;
import com.duoc.rentacar.ms_empleados.service.EmpleadoService;

@RestController
@RequestMapping("/api/empleados")
public class EmpleadoController {

    @Autowired
    private EmpleadoService service;

    @GetMapping
    public ResponseEntity<List<Empleado>> listar() {
        return ResponseEntity.ok(service.obtenerTodos());
    }

    @PostMapping
    public ResponseEntity<Empleado> guardar(@Valid @RequestBody Empleado emp) {
        return new ResponseEntity<>(service.registrar(emp), HttpStatus.CREATED);
    }
}