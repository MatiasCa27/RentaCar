package com.duoc.rentacar.ms_empleados.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Entity
@Table(name = "SUCURSAL")
@Data
public class Sucursal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_sucursal;

    @NotBlank(message = "El nombre de sucursal es obligatorio")
    private String nombre_sucursal;

    // Aquí guardamos el ID de la comuna como referencia
    // (IE 2.4.1: Referencia lógica a ms-ubicaciones)
    private Long id_comuna_ref; 
}