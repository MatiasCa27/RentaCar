package com.duoc.rentacar.ms_empleados.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.duoc.rentacar.ms_empleados.model.Empleado;
import com.duoc.rentacar.ms_empleados.repository.EmpleadoRepository;

@Service
public class EmpleadoService {
    private static final Logger logger = LoggerFactory.getLogger(EmpleadoService.class);

    @Autowired
    private EmpleadoRepository repository;

    public List<Empleado> obtenerTodos() {
        logger.info("Obteniendo nómina completa de empleados");
        return repository.findAll();
    }

    public Empleado registrar(Empleado emp) {
        logger.info("Registrando nuevo empleado: {} con RUN {}", emp.getNombre_emp(), emp.getNumrun_emp());
        return repository.save(emp);
    }
}