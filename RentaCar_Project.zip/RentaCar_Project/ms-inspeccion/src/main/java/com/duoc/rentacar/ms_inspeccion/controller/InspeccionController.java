package com.duoc.rentacar.ms_inspeccion.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.duoc.rentacar.ms_inspeccion.model.Inspeccion;
import com.duoc.rentacar.ms_inspeccion.service.InspeccionService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/inspecciones")
public class InspeccionController {

    @Autowired
    private InspeccionService service;

    @PostMapping
    public ResponseEntity<Inspeccion> crear(@Valid @RequestBody Inspeccion inspeccion) {
        return new ResponseEntity<>(service.registrarInspeccion(inspeccion), HttpStatus.CREATED);
    }
}