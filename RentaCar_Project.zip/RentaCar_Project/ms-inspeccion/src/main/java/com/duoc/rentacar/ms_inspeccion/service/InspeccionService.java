package com.duoc.rentacar.ms_inspeccion.service;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.duoc.rentacar.ms_inspeccion.model.Inspeccion;
import com.duoc.rentacar.ms_inspeccion.repository.InspeccionRepository;

@Service
public class InspeccionService {
    private static final Logger logger = LoggerFactory.getLogger(InspeccionService.class);

    @Autowired
    private InspeccionRepository repository;

    public Inspeccion registrarInspeccion(Inspeccion inspeccion) {
        logger.info("Registrando {} para la renta ID: {}", 
                    inspeccion.getTipo_inspeccion(), 
                    inspeccion.getId_renta_ref());
        
        inspeccion.setFecha_inspeccion(LocalDateTime.now());
        return repository.save(inspeccion);
    }
}