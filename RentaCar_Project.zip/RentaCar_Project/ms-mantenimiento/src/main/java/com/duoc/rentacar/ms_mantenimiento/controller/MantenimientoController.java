package com.duoc.rentacar.ms_mantenimiento.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.http.HttpStatus;
import jakarta.validation.Valid;

import com.duoc.rentacar.ms_mantenimiento.service.MantenimientoService;

import com.duoc.rentacar.ms_mantenimiento.model.Mantenimiento;

@RestController
@RequestMapping("/api/mantenimientos")
public class MantenimientoController {

    @Autowired
    private MantenimientoService service;

    @PostMapping
    public ResponseEntity<Mantenimiento> crear(@Valid @RequestBody Mantenimiento mant) {
        return new ResponseEntity<>(service.registrarIngreso(mant), HttpStatus.CREATED);
    }

    @GetMapping("/auto/{patente}")
    public ResponseEntity<List<Mantenimiento>> historial(@PathVariable String patente) {
        return ResponseEntity.ok(service.historialPorAuto(patente));
    }
}