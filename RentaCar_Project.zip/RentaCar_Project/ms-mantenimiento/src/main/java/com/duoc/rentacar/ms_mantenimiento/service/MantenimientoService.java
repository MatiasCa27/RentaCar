package com.duoc.rentacar.ms_mantenimiento.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.duoc.rentacar.ms_mantenimiento.model.Mantenimiento;
import com.duoc.rentacar.ms_mantenimiento.repository.MantenimientoRepository;

@Service
public class MantenimientoService {
    private static final Logger logger = LoggerFactory.getLogger(MantenimientoService.class);

    @Autowired
    private MantenimientoRepository repository;

    public Mantenimiento registrarIngreso(Mantenimiento mant) {
        logger.info("Ingresando vehículo patente {} a mantenimiento por: {}", 
                    mant.getPatente_auto_ref(), mant.getMotivo());
        return repository.save(mant);
    }

    public List<Mantenimiento> historialPorAuto(String patente) {
        logger.info("Consultando historial técnico del auto: {}", patente);
        return repository.findByPatenteAutoRef(patente);
    }
}