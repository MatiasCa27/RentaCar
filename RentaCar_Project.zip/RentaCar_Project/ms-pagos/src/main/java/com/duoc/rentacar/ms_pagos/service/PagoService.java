package com.duoc.rentacar.ms_pagos.service;

import com.duoc.rentacar.ms_pagos.model.Pago;
import com.duoc.rentacar.ms_pagos.repository.PagoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PagoService {
    private static final Logger logger = LoggerFactory.getLogger(PagoService.class);

    @Autowired 
    private PagoRepository repository;

    public Pago registrarPago(Pago pago) {
        logger.info("Registrando intención de pago para la renta ID: {}", pago.getId_renta_ref());
        
        pago.setEstado("PENDIENTE");
        return repository.save(pago);
    }
}