package com.duoc.rentacar.ms_tarifas.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.duoc.rentacar.ms_tarifas.model.Tarifa;
import com.duoc.rentacar.ms_tarifas.service.TarifaService;

@RestController
@RequestMapping("/api/tarifas")
public class TarifaController {

    @Autowired
    private TarifaService service;

    @GetMapping
    public ResponseEntity<List<Tarifa>> listar() {
        return ResponseEntity.ok(service.listarTarifas());
    }

    @GetMapping("/tipo/{idTipo}")
    public ResponseEntity<Tarifa> buscar(@PathVariable String idTipo) {
        Tarifa tarifa = service.obtenerPorTipoAuto(idTipo);
        return tarifa != null ? ResponseEntity.ok(tarifa) : ResponseEntity.notFound().build();
    }
}