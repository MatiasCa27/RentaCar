package com.duoc.rentacar.ms_tarifas.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;

@Entity
@Table(name = "TARIFA")
@Data
public class Tarifa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_tarifa;

    @NotBlank(message = "La descripción de la tarifa es obligatoria")
    private String descripcion; // Ej: "Temporada Alta", "Vehículo VIP"

    @Min(value = 1, message = "El valor debe ser mayor a 0")
    private Double valor_por_dia;

    // Referencia lógica al ID del tipo de auto en ms-catalogo (IE 2.4.1)
    private Long id_tipo_auto_ref;
}