package com.duoc.rentacar.ms_tarifas.service;


import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.duoc.rentacar.ms_tarifas.model.Tarifa;
import com.duoc.rentacar.ms_tarifas.repository.TarifaRepository;

@Service
public class TarifaService {
    private static final Logger logger = LoggerFactory.getLogger(TarifaService.class);

    @Autowired
    private TarifaRepository repository;

    public List<Tarifa> listarTarifas() {
        logger.info("Consultando el listado maestro de tarifas");
        return repository.findAll();
    }

    public Tarifa obtenerPorTipoAuto(String idTipo) {
        logger.info("Buscando tarifa aplicada para el tipo de auto ID: {}", idTipo);
        
        Long idTipoLong = Long.parseLong(idTipo);
        
        return repository.findByIdTipoAutoRef(idTipoLong).orElse(null);
    }
}