package com.duoc.rentacar.ms_ubicaciones.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.duoc.rentacar.ms_ubicaciones.model.Comuna;
import com.duoc.rentacar.ms_ubicaciones.repository.ComunaRepository;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class ComunaService {
    private static final Logger logger = LoggerFactory.getLogger(ComunaService.class);

    @Autowired
    private ComunaRepository repository;

    public List<Comuna> listarComunas() {
        logger.info("Consultando todas las comunas disponibles");
        return repository.findAll();
    }

    public Comuna guardar(Comuna comuna) {
        logger.info("Registrando nueva comuna: {}", comuna.getNombre_comuna());
        return repository.save(comuna);
    }
}