package com.duoc.rentacar.ms_catalogo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.duoc.rentacar.ms_catalogo.model.Auto;
import com.duoc.rentacar.ms_catalogo.service.AutoService;

@RestController
@RequestMapping("/api/autos")
public class AutoController {

    @Autowired
    private AutoService autoService;

    @GetMapping
    public ResponseEntity<List<Auto>> listarTodos() {
        List<Auto> lista = autoService.obtenerTodos();
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/{patente}")
    public ResponseEntity<Auto> buscarPorPatente(@PathVariable String patente) {
        Auto auto = autoService.buscarPorPatente(patente);
        return auto != null ? ResponseEntity.ok(auto) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Auto> guardar(@RequestBody Auto auto) {
        Auto nuevoAuto = autoService.guardarAuto(auto);
        return ResponseEntity.ok(nuevoAuto);
    }
}