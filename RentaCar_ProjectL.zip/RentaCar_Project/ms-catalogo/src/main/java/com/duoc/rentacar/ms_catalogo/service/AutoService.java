package com.duoc.rentacar.ms_catalogo.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.duoc.rentacar.ms_catalogo.model.Auto;
import com.duoc.rentacar.ms_catalogo.repository.AutoRepository;

@Service
public class AutoService {

    private static final Logger logger = LoggerFactory.getLogger(AutoService.class);

    @Autowired
    private AutoRepository autoRepository;

    public List<Auto> obtenerTodos() {
        logger.info("Consultando el catálogo completo de vehículos");
        return autoRepository.findAll();
    }

    
    public Auto buscarPorPatente(String patente) {
        logger.info("Buscando vehículo con patente: {}", patente);
        return autoRepository.findById(patente).orElse(null);
    }

    public Auto guardarAuto(Auto auto) {
        logger.info("Registrando/Actualizando vehículo con patente: {}", auto.getPatente());
        return autoRepository.save(auto);
    }
}