package com.duoc.rentacar.ms_clientes.service;

import java.util.List;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.duoc.rentacar.ms_clientes.model.Cliente;
import com.duoc.rentacar.ms_clientes.repository.ClienteRepository;

@Service
public class ClienteService {

    private static final Logger logger = LoggerFactory.getLogger(ClienteService.class);

    @Autowired
    private ClienteRepository repository;

    public List<Cliente> listarTodos() {
        logger.info("Consultando listado maestro de clientes");
        return repository.findAll();
    }

    public Cliente buscarPorId(Long id) {
        logger.info("Buscando cliente con ID: {}", id);
        if (id == null) return null;
        return repository.findById(id).orElse(null);
    }

    public Cliente guardar(Cliente cliente) {
        if (cliente == null) return null;
        logger.info("Guardando cliente: {} con RUT: {}", cliente.getNombre(), cliente.getRut());
        return repository.save(cliente);
    }

    public void eliminar(Long id) {
        if (id != null) {
            logger.warn("Eliminando registro de cliente con ID: {}", id);
            repository.deleteById(id);
        }
    }
}