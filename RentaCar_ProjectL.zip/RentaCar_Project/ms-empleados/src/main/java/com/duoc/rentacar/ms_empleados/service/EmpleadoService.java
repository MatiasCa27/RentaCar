package com.duoc.rentacar.ms_empleados.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.duoc.rentacar.ms_empleados.model.Empleado;
import com.duoc.rentacar.ms_empleados.repository.EmpleadoRepository;

@Service
public class EmpleadoService {

    private static final Logger logger = LoggerFactory.getLogger(EmpleadoService.class);

    @Autowired
    private EmpleadoRepository repository;

   
    public List<Empleado> obtenerTodos() {
        logger.info("Consultando la nómina completa de empleados en la base de datos");
        return repository.findAll();
    }

    public Empleado buscarPorId(Long id) {
        logger.info("Buscando ficha del empleado con ID: {}", id);
        if (id == null) return null;
        return repository.findById(id).orElse(null);
    }

    public Empleado registrar(Empleado emp) {
        if (emp == null) return null;
        logger.info("Registrando/Actualizando empleado: {} con RUN: {}", 
                    emp.getNombre_emp(), emp.getNombre_emp()); 
        return repository.save(emp);
    }

    public void eliminar(Long id) {
        if (id != null) {
            logger.warn("Se va a eliminar al empleado con ID: {}", id);
            repository.deleteById(id);
        }
    }
}