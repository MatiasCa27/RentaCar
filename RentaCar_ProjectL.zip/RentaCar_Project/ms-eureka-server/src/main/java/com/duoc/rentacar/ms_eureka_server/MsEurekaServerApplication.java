package com.duoc.rentacar.ms_eureka_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer // <--- ESTA es la única que debe estar para el servidor
public class MsEurekaServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(MsEurekaServerApplication.class, args);
    }
}