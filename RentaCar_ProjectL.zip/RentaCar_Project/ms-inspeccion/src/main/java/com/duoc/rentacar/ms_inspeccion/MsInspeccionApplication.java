package com.duoc.rentacar.ms_inspeccion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsInspeccionApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsInspeccionApplication.class, args);
	}

}
