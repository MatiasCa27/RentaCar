package com.duoc.rentacar.ms_mantenimiento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsMantenimientoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsMantenimientoApplication.class, args);
	}

}
