package com.duoc.rentacar.ms_mantenimiento.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.duoc.rentacar.ms_mantenimiento.model.Mantenimiento;
import com.duoc.rentacar.ms_mantenimiento.service.MantenimientoService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/mantenimientos")
public class MantenimientoController {

    @Autowired
    private MantenimientoService service;

    @PostMapping
    public ResponseEntity<Mantenimiento> crear(@Valid @RequestBody Mantenimiento mant) {
        return new ResponseEntity<>(service.registrarIngreso(mant), HttpStatus.CREATED);
    }

    @GetMapping("/auto/{patente}")
    public ResponseEntity<List<Mantenimiento>> historial(@PathVariable String patente) {
        return ResponseEntity.ok(service.historialPorAuto(patente));
    }

    @GetMapping
    public ResponseEntity<List<Mantenimiento>> listar() {

        return ResponseEntity.ok(service.listarMantenimientos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Mantenimiento> buscarPorId(
            @PathVariable Long id) {

        Mantenimiento mant = service.buscarPorId(id);

        if (mant != null) {
            return ResponseEntity.ok(mant);
        }

        return ResponseEntity.notFound().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Mantenimiento> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody Mantenimiento mant) {

        Mantenimiento actualizado = service.actualizar(id, mant);

        if (actualizado != null) {
            return ResponseEntity.ok(actualizado);
        }

        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {

        service.eliminar(id);

        return ResponseEntity.noContent().build();
    }
}