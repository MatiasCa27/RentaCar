package com.duoc.rentacar.ms_mantenimiento.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.duoc.rentacar.ms_mantenimiento.model.Mantenimiento;
import com.duoc.rentacar.ms_mantenimiento.repository.MantenimientoRepository;

@Service
public class MantenimientoService {
    private static final Logger logger = LoggerFactory.getLogger(MantenimientoService.class);

    @Autowired
    private MantenimientoRepository repository;

    public Mantenimiento registrarIngreso(Mantenimiento mant) {
        logger.info("Ingresando vehículo patente {} a mantenimiento por: {}", 
                    mant.getPatente_auto_ref(), mant.getMotivo());
        return repository.save(mant);
    }

    public List<Mantenimiento> historialPorAuto(String patente) {
        logger.info("Consultando historial técnico del auto: {}", patente);
        return repository.findByPatenteAutoRef(patente);
    }

    public List<Mantenimiento> listarMantenimientos() {

        logger.info("Consultando todos los mantenimientos");

        return repository.findAll();
    }

    public Mantenimiento buscarPorId(Long id) {

        logger.info("Buscando mantenimiento con ID: {}", id);

        return repository.findById(id).orElse(null);
    }

    public Mantenimiento actualizar(Long id, Mantenimiento mant) {

        logger.info("Actualizando mantenimiento con ID: {}", id);

        Mantenimiento existente = repository.findById(id).orElse(null);

        if (existente != null) {

            existente.setMotivo(mant.getMotivo());
            existente.setFecha_ingreso(mant.getFecha_ingreso());
            existente.setFecha_salida(mant.getFecha_salida());
            existente.setCosto_reparacion(mant.getCosto_reparacion());
            existente.setPatente_auto_ref(mant.getPatente_auto_ref());

            return repository.save(existente);
        }

        return null;
    }

    public void eliminar(Long id) {

        logger.info("Eliminando mantenimiento con ID: {}", id);

        repository.deleteById(id);
    }
}