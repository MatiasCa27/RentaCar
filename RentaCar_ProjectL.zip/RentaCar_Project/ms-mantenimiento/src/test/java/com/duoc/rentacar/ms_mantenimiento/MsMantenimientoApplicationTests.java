package com.duoc.rentacar.ms_mantenimiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsMantenimientoApplicationTests {

	@Test
	void contextLoads() {
	}

}
