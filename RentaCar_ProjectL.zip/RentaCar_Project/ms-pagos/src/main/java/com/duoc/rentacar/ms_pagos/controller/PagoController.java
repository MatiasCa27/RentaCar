package com.duoc.rentacar.ms_pagos.controller;

import com.duoc.rentacar.ms_pagos.model.Pago;
import com.duoc.rentacar.ms_pagos.service.PagoService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pagos")
public class PagoController {

    @Autowired
    private PagoService service;

    @GetMapping
    public ResponseEntity<List<Pago>> listar() {
        return ResponseEntity.ok(service.listarPagos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pago> buscarPorId(@PathVariable Long id) {

        Pago pago = service.buscarPorId(id);

        if (pago != null) {
            return ResponseEntity.ok(pago);
        }

        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Pago> registrarPago(
            @Valid @RequestBody Pago pago) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(service.registrarPago(pago));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Pago> actualizar(
            @PathVariable Long id,
            @RequestBody Pago pago) {

        Pago actualizado = service.actualizar(id, pago);

        if (actualizado != null) {
            return ResponseEntity.ok(actualizado);
        }

        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {

        service.eliminar(id);

        return ResponseEntity.noContent().build();
    }
}