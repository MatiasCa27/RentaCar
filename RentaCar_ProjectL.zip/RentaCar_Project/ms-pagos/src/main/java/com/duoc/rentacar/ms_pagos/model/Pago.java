package com.duoc.rentacar.ms_pagos.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "pago")
@Data
public class Pago {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_pago;

    private Double monto;
    private String estado; // Ejemplo: "PENDIENTE"
    
    // Referencia lógica al ID de la renta que se está pagando
    private Long id_renta_ref; 
}