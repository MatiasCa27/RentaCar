package com.duoc.rentacar.ms_pagos.repository;

import com.duoc.rentacar.ms_pagos.model.Pago;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PagoRepository extends JpaRepository<Pago, Long> {
    // Esta interfaz queda vacía, JpaRepository ya trae los métodos save, findAll, etc.
}