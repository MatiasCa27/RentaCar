package com.duoc.rentacar.ms_pagos.service;

import java.util.List;

import com.duoc.rentacar.ms_pagos.model.Pago;
import com.duoc.rentacar.ms_pagos.repository.PagoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PagoService {
    private static final Logger logger = LoggerFactory.getLogger(PagoService.class);

    @Autowired 
    private PagoRepository repository;

    public Pago registrarPago(Pago pago) {
        logger.info("Registrando intención de pago para la renta ID: {}", pago.getId_renta_ref());
        
        pago.setEstado("PENDIENTE");
        return repository.save(pago);
    }

    public List<Pago> listarPagos() {

        logger.info("Consultando listado de pagos");

        return repository.findAll();
    }

    public Pago buscarPorId(Long id) {

        logger.info("Buscando pago con ID: {}", id);

        return repository.findById(id).orElse(null);
    }

    public Pago actualizar(Long id, Pago pago) {

        logger.info("Actualizando pago con ID: {}", id);

        Pago pagoExistente = repository.findById(id).orElse(null);

        if (pagoExistente != null) {

            pagoExistente.setMonto(pago.getMonto());
            pagoExistente.setEstado(pago.getEstado());
            pagoExistente.setId_renta_ref(pago.getId_renta_ref());

            return repository.save(pagoExistente);
        }

        return null;
    }

    public void eliminar(Long id) {

        logger.info("Eliminando pago con ID: {}", id);

        repository.deleteById(id);
    }
}