package com.duoc.rentacar.ms_renta.client; // 1. Declaramos la ubicación exacta

import org.springframework.cloud.openfeign.FeignClient; // 2. Importamos Feign
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "ms-clientes") // Nombre que tiene el micro en su application.properties
public interface ClienteClient {

    @GetMapping("/api/clientes/{rut}")
    Object buscarPorRut(@PathVariable("rut") String rut);
}