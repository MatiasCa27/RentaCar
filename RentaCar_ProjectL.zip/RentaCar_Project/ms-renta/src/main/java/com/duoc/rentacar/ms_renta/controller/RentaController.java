package com.duoc.rentacar.ms_renta.controller;

import java.util.List;

import com.duoc.rentacar.ms_renta.model.Renta;
import com.duoc.rentacar.ms_renta.service.RentaService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rentas")
public class RentaController {

    @Autowired
    private RentaService service;

    @PostMapping
    public ResponseEntity<Renta> realizarRenta(
            @Valid @RequestBody Renta renta) {

        Renta nuevaRenta = service.realizarRenta(renta);

        if (nuevaRenta != null) {
            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(nuevaRenta);
        }

        return ResponseEntity.badRequest().build();
    }

    @GetMapping
    public ResponseEntity<List<Renta>> listar() {
        return ResponseEntity.ok(service.listarRentas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Renta> buscarPorId(@PathVariable Long id) {

        Renta renta = service.buscarPorId(id);

        if (renta != null) {
            return ResponseEntity.ok(renta);
        }

        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {

        service.eliminar(id);

        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Renta> actualizar(
            @PathVariable Long id,
            @RequestBody Renta renta) {

        Renta actualizada = service.actualizar(id, renta);

        if (actualizada != null) {
            return ResponseEntity.ok(actualizada);
        }

        return ResponseEntity.notFound().build();
    }

}