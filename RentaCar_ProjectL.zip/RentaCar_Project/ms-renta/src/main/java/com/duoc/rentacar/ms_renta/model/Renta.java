package com.duoc.rentacar.ms_renta.model; // 1. Corregido ms_renta

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Table(name = "RENTA_AUTO")
@Data
public class Renta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_renta;

    private LocalDate fecha_inicio;
    private Integer dias_renta;
    private Double monto_total;

    // Referencias lógicas (sin FK física)
    private Long rut_cliente_ref;
    private String patente_auto_ref;
}