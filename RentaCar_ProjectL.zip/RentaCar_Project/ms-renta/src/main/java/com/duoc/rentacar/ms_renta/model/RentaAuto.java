package com.duoc.rentacar.ms_renta.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Table(name = "RENTA_AUTO")
@Data
public class RentaAuto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_RENTA")
    private Long idRenta;

    @Column(name = "NRO_PATENTE")
    @NotNull(message = "La patente es obligatoria")
    private String nroPatente;

    @Column(name = "NUMRUN_CLI")
    @NotNull(message = "El RUN del cliente es obligatorio")
    private Long numrunCli;

    @Column(name = "FECHA_IN_RENTA")
    private LocalDate fechaInRenta; // Se eliminó @Temporal al usar LocalDate

    @Column(name = "DIAS_SOLICITADOS")
    private Integer diasSolicitados;

    // Referencias lógicas (IDs de otros microservicios)
    @Column(name = "ID_SUCURSAL")
    private Integer idSucursal;

    @Column(name = "NUMRUN_EMP")
    private Long numrunEmp;
}