package com.duoc.rentacar.ms_renta.service; // 1. Paquete corregido

import java.util.List;

import com.duoc.rentacar.ms_renta.model.Renta;
import com.duoc.rentacar.ms_renta.repository.RentaRepository;
import com.duoc.rentacar.ms_renta.client.AutoClient;
import com.duoc.rentacar.ms_renta.client.ClienteClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RentaService {
    private static final Logger logger = LoggerFactory.getLogger(RentaService.class);

    @Autowired private RentaRepository repository;
    @Autowired private AutoClient autoClient;      // Conexión a ms-catalogo
    @Autowired private ClienteClient clienteClient; // Conexión a ms-clientes

    public Renta realizarRenta(Renta renta) {
        logger.info("Iniciando proceso de renta para patente: {}", renta.getPatente_auto_ref());

        // 1. Validar remotamente el auto
        Object auto = autoClient.buscarPorPatente(renta.getPatente_auto_ref());
        if (auto == null) {
            logger.error("Validación fallida: El auto no existe en el catálogo.");
            return null;
        }

        // 2. Validar remotamente el cliente
        Object cliente = clienteClient.buscarPorRut(renta.getRut_cliente_ref().toString());
        if (cliente == null) {
            logger.error("Validación fallida: El cliente no existe en la base de datos.");
            return null;
        }

        // 3. Si ambos existen, guardamos
        logger.info("Auto y Cliente validados con éxito. Guardando registro de renta...");
        return repository.save(renta);
    }

    public List<Renta> listarRentas() {
        logger.info("Consultando listado de rentas");
        return repository.findAll();
    }

    public Renta buscarPorId(Long id) {

        logger.info("Buscando renta con ID: {}", id);

        return repository.findById(id).orElse(null);
    }

    public void eliminar(Long id) {

        logger.info("Eliminando renta con ID: {}", id);

        repository.deleteById(id);
    }

    public Renta actualizar(Long id, Renta renta) {

        logger.info("Actualizando renta con ID: {}", id);

        Renta rentaExistente = repository.findById(id).orElse(null);

        if (rentaExistente != null) {

            rentaExistente.setFecha_inicio(renta.getFecha_inicio());
            rentaExistente.setDias_renta(renta.getDias_renta());
            rentaExistente.setMonto_total(renta.getMonto_total());

            return repository.save(rentaExistente);
        }

        return null;
    }
}