package com.duoc.rentacar.ms_tarifas.service;


import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.duoc.rentacar.ms_tarifas.model.Tarifa;
import com.duoc.rentacar.ms_tarifas.repository.TarifaRepository;

@Service
public class TarifaService {
    private static final Logger logger = LoggerFactory.getLogger(TarifaService.class);

    @Autowired
    private TarifaRepository repository;

    public List<Tarifa> listarTarifas() {
        logger.info("Consultando el listado maestro de tarifas");
        return repository.findAll();
    }

    public Tarifa obtenerPorTipoAuto(String idTipo) {
        logger.info("Buscando tarifa aplicada para el tipo de auto ID: {}", idTipo);
        
        Long idTipoLong = Long.parseLong(idTipo);
        
        return repository.findByIdTipoAutoRef(idTipoLong).orElse(null);
    }

    public Tarifa guardar(Tarifa tarifa) {
        logger.info("Registrando nueva tarifa");

        return repository.save(tarifa);
    }

    public Tarifa actualizar(Long id, Tarifa tarifa) {

        logger.info("Actualizando tarifa con ID: {}", id);

        Tarifa tarifaExistente = repository.findById(id).orElse(null);

        if (tarifaExistente != null) {

            tarifaExistente.setDescripcion(tarifa.getDescripcion());
            tarifaExistente.setValorPorDia(tarifa.getValorPorDia());
            tarifaExistente.setIdTipoAutoRef(tarifa.getIdTipoAutoRef());

            return repository.save(tarifaExistente);
        }

        return null;
    }

    public void eliminar(Long id) {

        logger.info("Eliminando tarifa con ID: {}", id);

        repository.deleteById(id);
    }
}