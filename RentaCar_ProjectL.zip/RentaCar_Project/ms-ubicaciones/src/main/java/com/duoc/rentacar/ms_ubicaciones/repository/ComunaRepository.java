package com.duoc.rentacar.ms_ubicaciones.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.duoc.rentacar.ms_ubicaciones.model.Comuna;

public interface ComunaRepository extends JpaRepository<Comuna, Long> {
}